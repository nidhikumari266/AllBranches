package com.order.service.serviceImpl;

import com.order.entity.Order;
import com.order.mapper.OrderMapper;
import com.order.model.request.OrderRequest;
import com.order.repository.OrderRepository;
import com.order.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderServiceIMpl implements OrderService {

    @Autowired
    private OrderRepository  orderRepository;

    @Autowired
    private OrderMapper  orderMapper;


    @Override
    public String save(OrderRequest orderRequest) {
        Order order = orderMapper.toEntity(orderRequest);
        orderRepository.save(order);
        return "Order saved successfully";
    }
}

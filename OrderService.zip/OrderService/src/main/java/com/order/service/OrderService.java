package com.order.service;


import com.order.model.request.OrderRequest;
import jakarta.validation.Valid;

public interface OrderService {

    String save(OrderRequest request);
}

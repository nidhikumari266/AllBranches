package com.order.resources;


import com.order.model.request.OrderRequest;
import com.order.service.OrderService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/order")
public class OrderResource {

    @Autowired
    private OrderService orderService;


    @PostMapping
    public ResponseEntity<String> save(@Valid @RequestBody OrderRequest request) {
        String response = orderService.save(request);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }



}

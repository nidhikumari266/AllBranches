package com.order.mapper;

import com.order.entity.Order;
import com.order.model.request.OrderRequest;
import com.order.model.response.OrderResponse;
import org.mapstruct.Mapper;


@Mapper(componentModel = "spring")
public interface OrderMapper {

    Order toEntity(OrderRequest orderRequest);

    OrderResponse toResponse(Order order);
}
